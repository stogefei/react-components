import Upload from './upload'

export default Upload